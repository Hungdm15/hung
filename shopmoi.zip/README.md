# Website Bán Hàng

Website bán hàng được xây dựng bằng PHP với giao diện admin sử dụng Sneat Bootstrap template.

## Chức năng chính

### Phần Admin Dashboard
- **Quản lý người dùng**
  - Xem danh sách người dùng
  - Phân quyền admin/khách hàng
  - Xóa người dùng
  - Tìm kiếm, lọc và sắp xếp

- **Quản lý đơn hàng**
  - Xem danh sách đơn hàng
  - Cập nhật trạng thái đơn hàng (Chờ xử lý, Đang xử lý, Đang giao hàng, Hoàn thành, Đã hủy)
  - In đơn hàng
  - Tìm kiếm, lọc và sắp xếp đơn hàng
  - Xem chi tiết đơn hàng

- **Thống kê**
  - Thống kê doanh thu theo thời gian
  - Biểu đồ doanh thu
  - Tổng quan đơn hàng theo trạng thái
  - Lọc thống kê theo khoảng thời gian

### Phần Frontend
- **Sản phẩm**
  - Xem danh sách sản phẩm
  - Tìm kiếm sản phẩm
  - Lọc sản phẩm theo danh mục, giá, trạng thái
  - Sắp xếp sản phẩm
  - Xem chi tiết sản phẩm

- **Giỏ hàng & Đặt hàng**
  - Thêm sản phẩm vào giỏ hàng
  - Cập nhật số lượng
  - Xóa sản phẩm khỏi giỏ hàng
  - Đặt hàng và thanh toán

- **Tài khoản**
  - Đăng ký
  - Đăng nhập
  - Quản lý thông tin cá nhân
  - Xem lịch sử đơn hàng

### Tính năng khác
- Responsive design
- Tìm kiếm nâng cao với bộ lọc
- Phân trang
- Thông báo trạng thái
- Xác thực người dùng
- Phân quyền admin/khách hàng

## Công nghệ sử dụng
- PHP 8.2
- MySQL/PDO
- Bootstrap 5
- Sneat Admin Template
- JavaScript/jQuery
- HTML5/CSS3
- ApexCharts (cho biểu đồ)
- Font Awesome & BoxIcons

## Cấu trúc thư mục
```
├── admin/                # Trang quản trị
│   ├── assets/          # Resources cho admin
│   ├── layout/          # Layout files
│   └── *.php            # Các file chức năng admin
├── assets/              # Resources cho frontend
│   ├── css/
│   ├── js/
│   └── img/
├── config.php           # Cấu hình
├── functions.php        # Các hàm chung
└── *.php               # Các file chức năng frontend
```
